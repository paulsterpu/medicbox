import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Button, TextInput
} from "react-native";

class LoginScreen extends Component {

    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            cnp: '',
            password: ''
        };
    }

    render() {
        return (
            <View style={styles.container}>
                <TextInput
                    style={{height: 40, borderColor: 'gray', borderWidth: 1, width: 200}}
                    onChangeText={(cnp) => this.setState({cnp})}
                    placeholder={'CNP'}
                    value={this.state.text}
                />
                <TextInput
                    style={{height: 40, borderColor: 'gray', borderWidth: 1, width: 200}}
                    onChangeText={(password) => this.setState({password})}
                    placeholder={'Password'}
                    secureTextEntry={true}
                    value={this.state.text}
                />
                <Button title="Login"
                        onPress={() => this.props.navigation.navigate('PatientsList')} />
            </View>
        );
    }
}
export default LoginScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
});